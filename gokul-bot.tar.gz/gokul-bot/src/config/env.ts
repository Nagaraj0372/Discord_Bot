import 'dotenv/config';
import { z } from 'zod';
const schema = z.object({ NODE_ENV:z.enum(['development','test','production']).default('development'), DISCORD_TOKEN:z.string().min(1), CLIENT_ID:z.string().min(1), GUILD_ID:z.string().optional(), DATABASE_URL:z.string().url(), LAVALINK_HOST:z.string().default('localhost'), LAVALINK_PORT:z.coerce.number().default(2333), LAVALINK_PASSWORD:z.string().default('youshallnotpass'), LAVALINK_SECURE:z.coerce.boolean().default(false), HERMES_API_URL:z.string().url().optional().or(z.literal('')), HERMES_API_KEY:z.string().optional(), LOG_LEVEL:z.enum(['fatal','error','warn','info','debug','trace']).default('info'), PORT:z.coerce.number().default(3000), API_KEY:z.string().optional() });
export const env = schema.parse(process.env);
