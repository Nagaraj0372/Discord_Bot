import pino from 'pino'; import { env } from '../config/env.js'; export const logger = pino({ level: env.LOG_LEVEL, redact: ['DISCORD_TOKEN','HERMES_API_KEY','API_KEY','DATABASE_URL'] });
