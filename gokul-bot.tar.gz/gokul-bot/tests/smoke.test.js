import { describe, it, expect } from 'vitest';
import { cooldown } from '../src/utils/cooldown.js';
describe('utilities', () => { it('enforces cooldowns', () => { expect(cooldown('test', 1000)).toBe(0); expect(cooldown('test', 1000)).toBeGreaterThan(0); }); });
